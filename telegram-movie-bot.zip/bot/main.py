
from pyrogram import Client, filters

API_ID = 12345678
API_HASH = "your_api_hash"
BOT_TOKEN = "6392937872:AAHq8nDA-YmN-bfKc5KRZhXJPezRWikGd0U"
CHANNEL_USERNAME = "movieking143channel"

app = Client("movie_bot", api_id=API_ID, api_hash=API_HASH, bot_token=BOT_TOKEN)

@app.on_message(filters.command("start"))
def start(client, message):
    message.reply_text("Welcome to the Movie Bot!")

@app.on_message(filters.text & filters.private)
def search_movie(client, message):
    query = message.text.lower()
    for dialog in app.iter_dialogs():
        if dialog.chat.type == "channel" and dialog.chat.username == CHANNEL_USERNAME:
            for msg in app.search_messages(dialog.chat.id, query, limit=1):
                msg.copy(message.chat.id)
                return
    message.reply_text("Movie not found.")

app.run()
